package com.app61.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerFullstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerFullstackApplication.class, args);
	}

}
